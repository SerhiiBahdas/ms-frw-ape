FIG3.zip: data for Figure 3 (FIG3.m)

File
fig3_move_8_to_6.csv   movement move_8_to_6 without and with a torque pulse

Columns
time_s                                            time
qdd_sh_ref_unperturbed, qdd_el_ref_unperturbed    shoulder and elbow acceleration, physics engine, no pulse
tau_sh_unperturbed, tau_el_unperturbed            joint torques, no pulse
qdd_sh_ref_perturbed, qdd_el_ref_perturbed        shoulder and elbow acceleration, physics engine, with the pulse
tau_sh_perturbed, tau_el_perturbed                joint torques, with the pulse
qdd_sh_ape_perturbed, qdd_el_ape_perturbed        shoulder and elbow acceleration, APE, with the pulse
qdd_sh_ape_unperturbed, qdd_el_ape_unperturbed    shoulder and elbow acceleration, APE, no pulse

The torque pulse is the interval in which the perturbed torque differs from the unperturbed torque.

Notes
Angular accelerations are in rad/s^2, torques in N m and time in seconds. The sampling interval is 0.1 ms.
Row k of every column refers to sample k of the movement. time_s is the sample index
multiplied by the sampling interval.
The physics engine is the reference (ground truth) model of the two-segment arm.
The APE is the artificial physics engine: a neural network that returns joint accelerations,
followed by explicit Euler integration. Its simulation holds one sample fewer than the
reference, so the last row of its columns is empty.
Movements are named move_A_to_B, a reach from target A to target B, with A and B from 1 to 10
(90 ordered pairs).
"unperturbed" movements have no torque perturbation; "perturbed" movements are the same
reaches with a brief torque pulse at the shoulder or the elbow.
