FIG1.zip: data for panel c of Figure 1 (FIG1.m)

Files
fig1_move_4_to_8_unperturbed.csv   movement move_4_to_8 without a torque pulse
fig1_move_4_to_8_perturbed.csv     the same movement with a torque pulse

Columns
time_s                      time
q_sh_ref, q_el_ref          shoulder and elbow angle, physics engine
tau_sh, tau_el              shoulder and elbow torque applied to all three models
q_sh_ape, q_el_ape          shoulder and elbow angle, APE
q_sh_direct, q_el_direct    shoulder and elbow angle, direct mapping model

Notes
Joint angles are in radians, torques in N m and time in seconds. The sampling interval is 0.1 ms.
Row k of every column refers to sample k of the movement. time_s is the sample index
multiplied by the sampling interval.
The physics engine is the reference (ground truth) model of the two-segment arm.
The APE is the artificial physics engine: a neural network that returns joint accelerations,
followed by explicit Euler integration. Its simulation holds one sample fewer than the
reference, so the last row of its columns is empty.
The direct mapping model is a neural network that maps joint torques to joint angles.
Movements are named move_A_to_B, a reach from target A to target B, with A and B from 1 to 10
(90 ordered pairs).
"unperturbed" movements have no torque perturbation; "perturbed" movements are the same
reaches with a brief torque pulse at the shoulder or the elbow.
